-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : EZtojob
-- 
-- Part : #1
-- Date : 2015-06-29 22:41:49
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ez_action`
-- -----------------------------
DROP TABLE IF EXISTS `ez_action`;
CREATE TABLE `ez_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `ez_action`
-- -----------------------------
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `ez_action_log`;
CREATE TABLE `ez_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=359 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `ez_action_log`
-- -----------------------------
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_action_log` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_addons`
-- -----------------------------
DROP TABLE IF EXISTS `ez_addons`;
CREATE TABLE `ez_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `ez_addons`
-- -----------------------------
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_addons` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_adv`
-- -----------------------------
DROP TABLE IF EXISTS `ez_adv`;
CREATE TABLE `ez_adv` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `sn` int(11) DEFAULT NULL,
  `memo` varchar(1000) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_adv`
-- -----------------------------
INSERT INTO `ez_adv` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_adv` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_adv` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_adv` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_adv` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_adv` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_area`
-- -----------------------------
DROP TABLE IF EXISTS `ez_area`;
CREATE TABLE `ez_area` (
  `aid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '0',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '2',
  `pinyin` varchar(50) NOT NULL DEFAULT '',
  `first_letter` varchar(50) DEFAULT '',
  `short_url` varchar(255) DEFAULT '',
  `ishot` tinyint(4) DEFAULT '0',
  `sort` mediumint(9) DEFAULT '99',
  `acid` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `parent_id` (`pid`),
  KEY `region_type` (`type`),
  KEY `agency_id` (`pinyin`)
) ENGINE=MyISAM AUTO_INCREMENT=3415 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_area`
-- -----------------------------
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_area` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_area_copy`
-- -----------------------------
DROP TABLE IF EXISTS `ez_area_copy`;
CREATE TABLE `ez_area_copy` (
  `rid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '0',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '2',
  `pingyin` varchar(50) NOT NULL DEFAULT '',
  `short_url` varchar(255) DEFAULT '',
  PRIMARY KEY (`rid`),
  KEY `parent_id` (`pid`),
  KEY `region_type` (`type`),
  KEY `agency_id` (`pingyin`)
) ENGINE=MyISAM AUTO_INCREMENT=3409 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_area_copy`
-- -----------------------------
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_area_copy` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `ez_attachment`;
CREATE TABLE `ez_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `ez_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `ez_attribute`;
CREATE TABLE `ez_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `ez_attribute`
-- -----------------------------
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `ez_auth_extend`;
CREATE TABLE `ez_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `ez_auth_extend`
-- -----------------------------
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');
INSERT INTO `ez_auth_extend` VALUES ('', '', '');

-- -----------------------------
-- Table structure for `ez_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `ez_auth_group`;
CREATE TABLE `ez_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_auth_group`
-- -----------------------------
INSERT INTO `ez_auth_group` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_group` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `ez_auth_group_access`;
CREATE TABLE `ez_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_auth_group_access`
-- -----------------------------
INSERT INTO `ez_auth_group_access` VALUES ('', '');

-- -----------------------------
-- Table structure for `ez_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `ez_auth_rule`;
CREATE TABLE `ez_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=225 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_auth_rule`
-- -----------------------------
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_auth_rule` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_category`
-- -----------------------------
DROP TABLE IF EXISTS `ez_category`;
CREATE TABLE `ez_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `leixing` tinyint(1) DEFAULT '0' COMMENT '0二级分类1职位类别',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `ez_category`
-- -----------------------------
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_channel`
-- -----------------------------
DROP TABLE IF EXISTS `ez_channel`;
CREATE TABLE `ez_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_channel`
-- -----------------------------
INSERT INTO `ez_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_channel` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_collection`
-- -----------------------------
DROP TABLE IF EXISTS `ez_collection`;
CREATE TABLE `ez_collection` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '1' COMMENT '1job2company3video',
  `uid` int(11) DEFAULT '0',
  `toid` int(11) DEFAULT '0',
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`cid`),
  UNIQUE KEY `weiyi` (`uid`,`toid`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_collection`
-- -----------------------------
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');
INSERT INTO `ez_collection` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_company_articles`
-- -----------------------------
DROP TABLE IF EXISTS `ez_company_articles`;
CREATE TABLE `ez_company_articles` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_company_articles`
-- -----------------------------
INSERT INTO `ez_company_articles` VALUES ('', '', '', '', '');
INSERT INTO `ez_company_articles` VALUES ('', '', '', '', '');
INSERT INTO `ez_company_articles` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_company_leads`
-- -----------------------------
DROP TABLE IF EXISTS `ez_company_leads`;
CREATE TABLE `ez_company_leads` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `weibo` varchar(255) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_company_leads`
-- -----------------------------
INSERT INTO `ez_company_leads` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_company_leads` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_company_leads` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_company_leads` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_company_photo`
-- -----------------------------
DROP TABLE IF EXISTS `ez_company_photo`;
CREATE TABLE `ez_company_photo` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `weiyi` (`uid`,`url`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_company_photo`
-- -----------------------------
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_company_photo` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_company_video`
-- -----------------------------
DROP TABLE IF EXISTS `ez_company_video`;
CREATE TABLE `ez_company_video` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `swf_url` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT '0',
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`vid`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_company_video`
-- -----------------------------
INSERT INTO `ez_company_video` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_company_video` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_company_video` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_config`
-- -----------------------------
DROP TABLE IF EXISTS `ez_config`;
CREATE TABLE `ez_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_config`
-- -----------------------------
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_custom_model`
-- -----------------------------
DROP TABLE IF EXISTS `ez_custom_model`;
CREATE TABLE `ez_custom_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `titleName` varchar(255) DEFAULT '',
  `titleContent` varchar(1000) DEFAULT '',
  `createTime` int(11) DEFAULT '0',
  `updateTime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ez_document`
-- -----------------------------
DROP TABLE IF EXISTS `ez_document`;
CREATE TABLE `ez_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `ez_document`
-- -----------------------------
INSERT INTO `ez_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `ez_document_article`;
CREATE TABLE `ez_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `ez_document_article`
-- -----------------------------
INSERT INTO `ez_document_article` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `ez_document_download`;
CREATE TABLE `ez_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `ez_edu_experience`
-- -----------------------------
DROP TABLE IF EXISTS `ez_edu_experience`;
CREATE TABLE `ez_edu_experience` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `schoolName` varchar(50) DEFAULT '',
  `professional` varchar(50) DEFAULT '',
  `education` varchar(10) DEFAULT '',
  `startYear` varchar(10) DEFAULT '',
  `endYear` varchar(10) DEFAULT '',
  `isDel` tinyint(1) DEFAULT '0',
  `schoolBadge` varchar(255) DEFAULT '',
  `whetherGraduate` tinyint(1) DEFAULT '1',
  `createTime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_edu_experience`
-- -----------------------------
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_edu_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_email_tpl`
-- -----------------------------
DROP TABLE IF EXISTS `ez_email_tpl`;
CREATE TABLE `ez_email_tpl` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '1',
  `type` tinyint(4) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `content` text,
  `memo` varchar(255) DEFAULT '',
  `uid` int(11) DEFAULT '0',
  `addtime` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_email_tpl`
-- -----------------------------
INSERT INTO `ez_email_tpl` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_email_tpl` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_email_tpl` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_email_tpl` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_email_tpl` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_email_tpl` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_feed`
-- -----------------------------
DROP TABLE IF EXISTS `ez_feed`;
CREATE TABLE `ez_feed` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '0' COMMENT 'shangyiji mid',
  `uid` int(11) DEFAULT '0',
  `username` varchar(255) DEFAULT '',
  `content` varchar(1000) DEFAULT NULL,
  `ip` varchar(50) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_feed`
-- -----------------------------
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_feed` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_feedback`
-- -----------------------------
DROP TABLE IF EXISTS `ez_feedback`;
CREATE TABLE `ez_feedback` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `qq` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `ip` varchar(50) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  `feedbackPage` varchar(255) DEFAULT '',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_feedback`
-- -----------------------------
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_feedback` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_file`
-- -----------------------------
DROP TABLE IF EXISTS `ez_file`;
CREATE TABLE `ez_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `ez_file`
-- -----------------------------
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_file` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `ez_hooks`;
CREATE TABLE `ez_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_hooks`
-- -----------------------------
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `ez_hooks` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_jobs`
-- -----------------------------
DROP TABLE IF EXISTS `ez_jobs`;
CREATE TABLE `ez_jobs` (
  `jid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) DEFAULT '0' COMMENT '0待审核1审核通过-1未通过',
  `uid` int(11) DEFAULT '0',
  `cid` int(11) DEFAULT '0',
  `hangye_lingyu` varchar(50) DEFAULT '',
  `zhiwei_leibie` varchar(255) DEFAULT '',
  `zid` int(11) DEFAULT '0',
  `zhiwei_mingcheng` varchar(50) DEFAULT '',
  `suoshu_bumen` varchar(50) DEFAULT '' COMMENT '所属部门',
  `gongzuo_xingzhi` varchar(255) DEFAULT '' COMMENT '工作性质：全职、兼职、实习',
  `yuexin_min` tinyint(4) DEFAULT '0',
  `yuexin_max` tinyint(4) DEFAULT '0',
  `gongzuo_chengshi` varchar(50) DEFAULT '',
  `gongzuo_jingyan` varchar(50) DEFAULT '',
  `xueli` varchar(50) DEFAULT '',
  `zhiwei_youhuo` varchar(50) DEFAULT NULL,
  `descrip` varchar(5000) DEFAULT '',
  `gongzuo_dizhi` varchar(255) DEFAULT '',
  `lat` varchar(50) DEFAULT '',
  `lng` varchar(50) DEFAULT '',
  `send_email` varchar(50) DEFAULT '',
  `forward_email` varchar(50) DEFAULT '',
  `init_time` int(11) DEFAULT '0',
  `addtime` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `offline_time` int(11) DEFAULT '0',
  `hits` int(11) DEFAULT '0',
  `tj_index` tinyint(1) DEFAULT '0' COMMENT '是否首页推荐',
  PRIMARY KEY (`jid`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_jobs`
-- -----------------------------
INSERT INTO `ez_jobs` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_jobs_apply`
-- -----------------------------
DROP TABLE IF EXISTS `ez_jobs_apply`;
CREATE TABLE `ez_jobs_apply` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) DEFAULT '0' COMMENT '0待处理/投递成功、待沟通(查看联系方式)-1不适合-2自动过滤1安排面试',
  `jid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `rid` int(11) DEFAULT '0' COMMENT '简历id：0在线',
  `interviewTime` varchar(50) DEFAULT '',
  `tel` varchar(50) DEFAULT NULL,
  `addtime` int(11) DEFAULT '0',
  `isread` tinyint(1) DEFAULT '0',
  `view_contact` tinyint(1) DEFAULT '0' COMMENT '是否查看联系方式',
  `company_id` int(11) DEFAULT '0',
  `biaoshi` tinyint(1) DEFAULT '0' COMMENT '是否标示',
  `zhuanfa` tinyint(4) DEFAULT '0' COMMENT '是否转发',
  `contactEmail` varchar(50) DEFAULT NULL,
  `contactName` varchar(50) DEFAULT NULL,
  `contactPhone` varchar(50) DEFAULT NULL,
  `viewTime` int(11) DEFAULT '0',
  `zhuanfa_str` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`aid`),
  UNIQUE KEY `weiyi` (`jid`,`uid`,`addtime`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_jobs_apply`
-- -----------------------------
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_jobs_apply_forward`
-- -----------------------------
DROP TABLE IF EXISTS `ez_jobs_apply_forward`;
CREATE TABLE `ez_jobs_apply_forward` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) DEFAULT '0',
  `aid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `email` varchar(50) DEFAULT '',
  `send_time` int(11) DEFAULT '0',
  `code` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `is_check` tinyint(1) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_jobs_apply_forward`
-- -----------------------------
INSERT INTO `ez_jobs_apply_forward` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_forward` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_forward` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_jobs_apply_log`
-- -----------------------------
DROP TABLE IF EXISTS `ez_jobs_apply_log`;
CREATE TABLE `ez_jobs_apply_log` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '0' COMMENT '1投递简历2简历被查看3查看联系方式（待沟通）4面试10不合适',
  `aid` int(11) DEFAULT '0' COMMENT '申请记录id',
  `uid` int(11) DEFAULT '0',
  `from_uid` int(11) DEFAULT NULL,
  `content` varchar(255) DEFAULT '' COMMENT '日志内容',
  `ext_data` varchar(1000) DEFAULT NULL COMMENT '附加内容',
  `opt_time` int(11) DEFAULT '0',
  PRIMARY KEY (`lid`),
  UNIQUE KEY `weiyi` (`aid`,`uid`,`opt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_jobs_apply_log`
-- -----------------------------
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_jobs_apply_log` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_link`
-- -----------------------------
DROP TABLE IF EXISTS `ez_link`;
CREATE TABLE `ez_link` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `sn` int(11) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_link`
-- -----------------------------
INSERT INTO `ez_link` VALUES ('', '', '', '', '');
INSERT INTO `ez_link` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_member`
-- -----------------------------
DROP TABLE IF EXISTS `ez_member`;
CREATE TABLE `ez_member` (
  `uid` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) DEFAULT '0' COMMENT '-1禁用0刚注册1待激活2待完善资料100资料已完善',
  `user_status` tinyint(1) DEFAULT '1' COMMENT '用户身份状态：0禁用1启用',
  `type` tinyint(1) DEFAULT '0' COMMENT '0找工作1招人',
  `isv` tinyint(1) DEFAULT '0' COMMENT '0待提交资料1审核中2审核成功-1审核失败',
  `yingye_zhizhao` varchar(255) DEFAULT NULL,
  `hits` int(11) DEFAULT '0' COMMENT '被查看次数',
  `tj_index` tinyint(1) DEFAULT '0' COMMENT '是否首页推荐',
  `birthday` varchar(50) DEFAULT '',
  `qq` varchar(50) DEFAULT '',
  `score` mediumint(9) DEFAULT '0' COMMENT '用户积分',
  `sex` tinyint(3) DEFAULT '0' COMMENT '性别',
  `login_num` int(11) DEFAULT '0',
  `edu` varchar(255) DEFAULT '',
  `pic` varchar(255) DEFAULT '',
  `money` decimal(10,2) DEFAULT NULL,
  `gongsi_xingzhi` varchar(50) DEFAULT '',
  `email_send_time` int(11) DEFAULT NULL,
  `email_check_time` int(11) DEFAULT NULL,
  `email_jianli` varchar(255) DEFAULT NULL,
  `email_key` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `workyear` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT '',
  `bind_from` tinyint(4) DEFAULT '0' COMMENT '0zhuce1sina2qq3weixin',
  `sina_open_id` varchar(255) DEFAULT NULL,
  `qq_open_id` varchar(255) DEFAULT NULL,
  `wx_open_id` varchar(255) DEFAULT NULL,
  `sina_name` varchar(255) DEFAULT NULL,
  `qq_name` varchar(255) DEFAULT NULL,
  `wx_name` varchar(255) DEFAULT NULL,
  `sina_bind_time` int(11) DEFAULT '0',
  `qq_bind_time` int(11) DEFAULT NULL,
  `wx_bind_time` int(11) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `realname` varchar(50) DEFAULT '',
  `idcard` varchar(50) DEFAULT '',
  `reg_ip` varchar(50) DEFAULT NULL,
  `reg_time` int(11) DEFAULT '0',
  `last_login_ip` bigint(20) DEFAULT '0',
  `last_login_time` int(11) DEFAULT '0',
  `check_email` tinyint(1) DEFAULT '0' COMMENT '邮箱验证:0未验证邮箱1正常验证通过',
  `company_name` varchar(255) DEFAULT '',
  `company_short_name` varchar(50) DEFAULT '',
  `logo` varchar(1000) DEFAULT '',
  `company_city_id` int(11) DEFAULT '0',
  `company_city` varchar(255) DEFAULT '',
  `web_url` varchar(255) DEFAULT '',
  `hangye_id` int(11) DEFAULT '0',
  `hangye` varchar(255) DEFAULT '',
  `guimu` varchar(50) DEFAULT '',
  `jieduan` varchar(50) DEFAULT '',
  `jigou` varchar(1000) DEFAULT '',
  `descri` varchar(1000) DEFAULT '',
  `tags` varchar(1000) DEFAULT '',
  `leads` varchar(1000) DEFAULT '',
  `products` varchar(1000) DEFAULT '',
  `content` text,
  `xiujia_fromDate` varchar(50) DEFAULT '',
  `xiujia_endDate` varchar(50) DEFAULT '',
  `resume_name` varchar(255) DEFAULT '' COMMENT '我的简历',
  `workstatus` varchar(50) DEFAULT '' COMMENT '目前工作状态',
  `update_time` int(11) DEFAULT '0' COMMENT '最新更新时间',
  `score_touxiang` tinyint(4) DEFAULT '0',
  `score_jiben` tinyint(4) DEFAULT '0',
  `score_jineng` tinyint(4) DEFAULT '0',
  `score_jingyan` tinyint(4) DEFAULT '0',
  `score_xiangmu` tinyint(4) DEFAULT '0',
  `score_jiaoyu` tinyint(4) DEFAULT '0',
  `score_ziwo` tinyint(4) DEFAULT '0',
  `score_zuopin` tinyint(4) DEFAULT '0',
  `score_custom` tinyint(4) DEFAULT '0',
  `resume_status` tinyint(4) DEFAULT '0' COMMENT '1已经完善',
  `city` varchar(50) DEFAULT '',
  `expect_city` varchar(50) DEFAULT '',
  `expect_memo` varchar(1000) DEFAULT '',
  `position_name` varchar(50) DEFAULT '',
  `position_type` varchar(50) DEFAULT '',
  `salarys` varchar(255) DEFAULT '',
  `remark` varchar(1000) DEFAULT '',
  `offline_resume_id` int(255) DEFAULT '0',
  `default_select` tinyint(50) DEFAULT '-1',
  `oneWord` varchar(255) DEFAULT '',
  `isOpenMyResume` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_member`
-- -----------------------------
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_menu`
-- -----------------------------
DROP TABLE IF EXISTS `ez_menu`;
CREATE TABLE `ez_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_menu`
-- -----------------------------
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_menu` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_model`
-- -----------------------------
DROP TABLE IF EXISTS `ez_model`;
CREATE TABLE `ez_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `ez_model`
-- -----------------------------
INSERT INTO `ez_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_news`
-- -----------------------------
DROP TABLE IF EXISTS `ez_news`;
CREATE TABLE `ez_news` (
  `nid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '1',
  `uid` tinyint(4) DEFAULT '0',
  `is_admin` tinyint(4) DEFAULT '0',
  `type` tinyint(1) DEFAULT '0' COMMENT '0单页面1新闻2通知公告3求职礼包4帮助信息',
  `cid` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `content` text,
  `thumb` varchar(255) DEFAULT '',
  `sort` int(11) DEFAULT '99',
  `hits` int(11) DEFAULT '0',
  `show_time` varchar(50) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `attach_name` varchar(255) DEFAULT NULL,
  `attach_url` varchar(255) DEFAULT NULL COMMENT '附件路径',
  `attach_id` int(11) DEFAULT '0',
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_news`
-- -----------------------------
INSERT INTO `ez_news` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_news` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_news` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_news` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_news` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_news` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_notice_tpl`
-- -----------------------------
DROP TABLE IF EXISTS `ez_notice_tpl`;
CREATE TABLE `ez_notice_tpl` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '1',
  `type` varchar(50) DEFAULT NULL COMMENT '1面试通知模板 REFUSE_TEMPLATE:不合适通知模板',
  `isdefault` tinyint(1) DEFAULT '0' COMMENT '0否1是',
  `isdelete` tinyint(1) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `content` text,
  `uid` int(11) DEFAULT '0',
  `link_address` varchar(255) DEFAULT '',
  `link_name` varchar(255) DEFAULT '',
  `link_phone` varchar(255) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `is_system` tinyint(1) DEFAULT '0' COMMENT '1',
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_notice_tpl`
-- -----------------------------
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_notice_tpl` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_picture`
-- -----------------------------
DROP TABLE IF EXISTS `ez_picture`;
CREATE TABLE `ez_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_picture`
-- -----------------------------
INSERT INTO `ez_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `ez_picture` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_pro_experience`
-- -----------------------------
DROP TABLE IF EXISTS `ez_pro_experience`;
CREATE TABLE `ez_pro_experience` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `startYear` varchar(10) DEFAULT '',
  `startMonth` varchar(10) DEFAULT '',
  `endYear` varchar(10) DEFAULT '',
  `endMonth` varchar(10) DEFAULT '',
  `positionName` varchar(50) DEFAULT '',
  `projectName` varchar(255) DEFAULT '',
  `projectRemark` varchar(5000) DEFAULT '',
  `isDel` tinyint(1) DEFAULT '0',
  `createTime` int(11) DEFAULT '0',
  `startDate` varchar(50) DEFAULT '',
  `endDate` varchar(50) DEFAULT '',
  `dutyRemark` varchar(50) DEFAULT '',
  `projectUrl` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_pro_experience`
-- -----------------------------
INSERT INTO `ez_pro_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_pro_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_report`
-- -----------------------------
DROP TABLE IF EXISTS `ez_report`;
CREATE TABLE `ez_report` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '1' COMMENT '1职位',
  `toid` int(50) DEFAULT '0',
  `content` text,
  `ip` varchar(50) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  `isAnonymous` tinyint(1) DEFAULT '0',
  `reason` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_report`
-- -----------------------------
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_report` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_resume_offline`
-- -----------------------------
DROP TABLE IF EXISTS `ez_resume_offline`;
CREATE TABLE `ez_resume_offline` (
  `oid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) DEFAULT '1',
  `type` tinyint(4) DEFAULT '1',
  `is_default` tinyint(4) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT '',
  `path` varchar(255) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  `ext` varchar(50) DEFAULT 'doc' COMMENT '后缀',
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_resume_offline`
-- -----------------------------
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `ez_resume_offline` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_school`
-- -----------------------------
DROP TABLE IF EXISTS `ez_school`;
CREATE TABLE `ez_school` (
  `sid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '1',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `cid` int(11) DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `pinyin` varchar(50) NOT NULL DEFAULT '',
  `first_letter` varchar(50) DEFAULT '',
  `ishot` tinyint(4) DEFAULT '0',
  `sort` mediumint(9) DEFAULT '99',
  PRIMARY KEY (`sid`),
  KEY `parent_id` (`pid`),
  KEY `region_type` (`type`),
  KEY `agency_id` (`pinyin`)
) ENGINE=MyISAM AUTO_INCREMENT=3419 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_school`
-- -----------------------------
INSERT INTO `ez_school` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_school` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_school` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_subscribe`
-- -----------------------------
DROP TABLE IF EXISTS `ez_subscribe`;
CREATE TABLE `ez_subscribe` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '1',
  `uid` int(11) DEFAULT '0',
  `city` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT NULL,
  `industryField` varchar(255) DEFAULT NULL,
  `positionName` varchar(255) DEFAULT NULL,
  `salary_min` tinyint(4) DEFAULT '0',
  `salary_max` tinyint(4) DEFAULT '0',
  `sendMailPer` tinyint(4) DEFAULT '0',
  `financeStage` varchar(255) DEFAULT '',
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`sid`),
  UNIQUE KEY `weiyi` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_subscribe`
-- -----------------------------
INSERT INTO `ez_subscribe` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `ez_ucenter_admin`;
CREATE TABLE `ez_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `ez_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `ez_ucenter_app`;
CREATE TABLE `ez_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `ez_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `ez_ucenter_member`;
CREATE TABLE `ez_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(32) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=100050 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `ez_ucenter_member`
-- -----------------------------
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `ez_ucenter_setting`;
CREATE TABLE `ez_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `ez_url`
-- -----------------------------
DROP TABLE IF EXISTS `ez_url`;
CREATE TABLE `ez_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `ez_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `ez_userdata`;
CREATE TABLE `ez_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ez_video`
-- -----------------------------
DROP TABLE IF EXISTS `ez_video`;
CREATE TABLE `ez_video` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) DEFAULT '1',
  `type` tinyint(4) DEFAULT '1' COMMENT '1视频2日历',
  `uid` int(11) DEFAULT '0' COMMENT '所属公司id',
  `cid` int(11) DEFAULT '0' COMMENT '城市id',
  `sid` int(11) DEFAULT '0' COMMENT '所属学校id',
  `title` varchar(255) DEFAULT '',
  `related` varchar(255) DEFAULT NULL COMMENT '右上角相关公司名',
  `thumb` varchar(255) DEFAULT '',
  `attach` varchar(1000) DEFAULT NULL,
  `shichang` varchar(50) DEFAULT NULL,
  `hits` int(11) DEFAULT '0',
  `url` varchar(500) DEFAULT '',
  `address` varchar(255) DEFAULT NULL,
  `content` text,
  `addtime` int(11) DEFAULT '0',
  `school` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `date_ymd` varchar(50) DEFAULT NULL,
  `date_time` varchar(50) DEFAULT NULL,
  `admin_uid` int(11) DEFAULT '0',
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_video`
-- -----------------------------
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_video` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_video_review`
-- -----------------------------
DROP TABLE IF EXISTS `ez_video_review`;
CREATE TABLE `ez_video_review` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) DEFAULT '0' COMMENT '1通过审核显示0不显示',
  `uid` int(11) DEFAULT '0',
  `vid` tinyint(4) DEFAULT '0',
  `content` text,
  `addtime` int(11) DEFAULT '0',
  `niming` tinyint(1) DEFAULT '0',
  `ip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_video_review`
-- -----------------------------
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_video_review` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_work_experience`
-- -----------------------------
DROP TABLE IF EXISTS `ez_work_experience`;
CREATE TABLE `ez_work_experience` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `companyName` varchar(50) DEFAULT '',
  `positionName` varchar(50) DEFAULT '',
  `startDate` varchar(20) DEFAULT '',
  `endDate` varchar(20) DEFAULT '',
  `isUploadLogo` tinyint(1) DEFAULT '0',
  `companyLogo` varchar(255) DEFAULT 'Public/Images/logo_default.png',
  `isDel` tinyint(1) DEFAULT '0',
  `createTime` int(11) DEFAULT '0',
  `workContent` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_work_experience`
-- -----------------------------
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ez_work_experience` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_work_show`
-- -----------------------------
DROP TABLE IF EXISTS `ez_work_show`;
CREATE TABLE `ez_work_show` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `workName` varchar(50) DEFAULT '',
  `url` varchar(50) DEFAULT '',
  `isDel` tinyint(1) DEFAULT '0',
  `createTime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_work_show`
-- -----------------------------
INSERT INTO `ez_work_show` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `ez_work_skill`
-- -----------------------------
DROP TABLE IF EXISTS `ez_work_skill`;
CREATE TABLE `ez_work_skill` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `skillPercent` varchar(255) DEFAULT '',
  `skillName` varchar(255) DEFAULT '',
  `masterLevel` varchar(255) DEFAULT '',
  `createTime` int(11) DEFAULT '0',
  `updateTime` int(11) DEFAULT '0',
  `isDel` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ez_work_skill`
-- -----------------------------
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `ez_work_skill` VALUES ('', '', '', '', '', '', '', '');
